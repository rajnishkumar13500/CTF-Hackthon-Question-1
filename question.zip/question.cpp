#include <iostream>
using namespace std;
int main(void)
{
  int arr[10];
  int arr_num[]={1,4567893452,34,67,3,8,6,5};// the value 4567893452 is out of the range of int datatype
  int num,i;

   cout << "Enter the count of numbers? ";
   cin >> num;
  

  for (i = 0; i < num; i++)
  {
    cout << "Enter a number to be stored: "; // in order to crash the application using the buffer flow vulnerability 
    cin >> arr_num[i];							// we need to provide a number that is not in the integer range of the array
    										//i.e not in the range of -2,147,483,648 to 2,147,483,647 
    										//so by changing the input of arr_num to greater than the range of the integer we will able to crash the application 
    										// using the buffer flow vulnerability
    arr[i]= arr_num;						//Buffer overflow is an runtime error that is why we are getting the warning of overflow in implicit constant 
    
  }
  return 0;
}
